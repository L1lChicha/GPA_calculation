package com.example;

public interface ItemClickListener {
    void onClick(String s);
}
