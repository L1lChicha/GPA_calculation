package com.example;

public class Item {
    String  subject;

    public Item(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }
}
